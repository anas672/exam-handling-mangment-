﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WebApplication6.Data;
using WebApplication6.Models;

namespace WebApplication6.Controllers
{
	public class ExamsController : Controller
	{
		private readonly WebDpContext _context;

		public ExamsController(WebDpContext context)
		{
			_context = context;
		}

		// GET: Exams
		public async Task<IActionResult> Index()
		{
			return View(await _context.Tbl_Exam.ToListAsync());
		}

		// GET: Exams/Details/5
		public async Task<IActionResult> Details(int? id)
		{
			if (id == null)
			{
				return NotFound();
			}

			var exam = await _context.Tbl_Exam
				.Include(e => e.Creator)
				.FirstOrDefaultAsync(m => m.ExamID == id);
			if (exam == null)
			{
				return NotFound();
			}

			return View(exam);
		}

		// GET: Exams/Create
		public IActionResult Create()
		{
			ViewData["CreatedBy"] = new SelectList(_context.Tbl_User, "UserID", "Username");
			return View();
		}

		// POST: Exams/Create
		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Create([Bind("ExamID,ExamName,Description,CreatedBy")] Exam exam)
		{
			if (ModelState.IsValid)
			{
				_context.Add(exam);
				await _context.SaveChangesAsync();
				return RedirectToAction(nameof(Index));
			}
			ViewData["CreatedBy"] = new SelectList(_context.Tbl_User, "UserID", "Username", exam.CreatedBy);
			return View(exam);
		}

		// GET: Exams/Edit/5
		public async Task<IActionResult> Edit(int? id)
		{
			if (id == null)
			{
				return NotFound();
			}

			var exam = await _context.Tbl_Exam.FindAsync(id);
			if (exam == null)
			{
				return NotFound();
			}
			ViewData["CreatedBy"] = new SelectList(_context.Tbl_User, "UserID", "Username", exam.CreatedBy);
			return View(exam);
		}

		// POST: Exams/Edit/5
		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Edit(int id, [Bind("ExamID,ExamName,Description,CreatedBy")] Exam exam)
		{
			if (id != exam.ExamID)
			{
				return NotFound();
			}

			if (ModelState.IsValid)
			{
				try
				{
					_context.Update(exam);
					await _context.SaveChangesAsync();
				}
				catch (DbUpdateConcurrencyException)
				{
					if (!ExamExists(exam.ExamID))
					{
						return NotFound();
					}
					else
					{
						throw;
					}
				}
				return RedirectToAction(nameof(Index));
			}
			ViewData["CreatedBy"] = new SelectList(_context.Tbl_User, "UserID", "Username", exam.CreatedBy);
			return View(exam);
		}

		// GET: Exams/Delete/5
		public async Task<IActionResult> Delete(int? id)
		{
			if (id == null)
			{
				return NotFound();
			}

			var exam = await _context.Tbl_Exam
				.Include(e => e.Creator)
				.FirstOrDefaultAsync(m => m.ExamID == id);
			if (exam == null)
			{
				return NotFound();
			}

			return View(exam);
		}

		// POST: Exams/Delete/5
		[HttpPost, ActionName("Delete")]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> DeleteConfirmed(int id)
		{
			var exam = await _context.Tbl_Exam.FindAsync(id);
			if (exam != null)
			{
				_context.Tbl_Exam.Remove(exam);
				await _context.SaveChangesAsync();
			}
			return RedirectToAction(nameof(Index));
		}

		private bool ExamExists(int id)
		{
			return _context.Tbl_Exam.Any(e => e.ExamID == id);
		}
	}
}
