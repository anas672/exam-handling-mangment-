﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Linq;
using WebApplication6.Data;

namespace WebApplication6.Controllers
{
    public class TestController : Controller
    {
        private readonly WebDpContext _context;

        public TestController(WebDpContext context)
        {
            _context = context;
        }

        public IActionResult CheckConnection()
        {
            try
            {
                // Attempt to retrieve data from the Tbl_User table
                var users = _context.Tbl_User.ToList();
                var message = $"Connection successful. Users found: {users.Count}";
                return View("ConnectionResult", model: message);
            }
            catch (Exception ex)
            {
                var message = $"Connection failed: {ex.Message}";
                return View("ConnectionResult", model: message);
            }
        }
    }
}
