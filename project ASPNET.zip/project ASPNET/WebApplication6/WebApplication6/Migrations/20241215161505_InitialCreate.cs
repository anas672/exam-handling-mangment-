﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace WebApplication6.Migrations
{
    /// <inheritdoc />
    public partial class InitialCreate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Tbl_User",
                columns: table => new
                {
                    UserID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Username = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Password = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Role = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Tbl_User", x => x.UserID);
                });

            migrationBuilder.CreateTable(
                name: "Tbl_Exam",
                columns: table => new
                {
                    ExamID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ExamName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    DateCreated = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatedBy = table.Column<int>(type: "int", nullable: false),
                    CreatorUserID = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Tbl_Exam", x => x.ExamID);
                    table.ForeignKey(
                        name: "FK_Tbl_Exam_Tbl_User_CreatorUserID",
                        column: x => x.CreatorUserID,
                        principalTable: "Tbl_User",
                        principalColumn: "UserID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Tbl_Question",
                columns: table => new
                {
                    QuestionID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ExamID = table.Column<int>(type: "int", nullable: false),
                    QuestionText = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    QuestionType = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Tbl_Question", x => x.QuestionID);
                    table.ForeignKey(
                        name: "FK_Tbl_Question_Tbl_Exam_ExamID",
                        column: x => x.ExamID,
                        principalTable: "Tbl_Exam",
                        principalColumn: "ExamID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Tbl_Result",
                columns: table => new
                {
                    ResultID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UserID = table.Column<int>(type: "int", nullable: false),
                    ExamID = table.Column<int>(type: "int", nullable: false),
                    Score = table.Column<decimal>(type: "decimal(5,2)", nullable: false),
                    DateTaken = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Tbl_Result", x => x.ResultID);
                    table.ForeignKey(
                        name: "FK_Tbl_Result_Tbl_Exam_ExamID",
                        column: x => x.ExamID,
                        principalTable: "Tbl_Exam",
                        principalColumn: "ExamID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Tbl_Result_Tbl_User_UserID",
                        column: x => x.UserID,
                        principalTable: "Tbl_User",
                        principalColumn: "UserID");
                });

            migrationBuilder.CreateTable(
                name: "Tbl_Answer",
                columns: table => new
                {
                    AnswerID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    QuestionID = table.Column<int>(type: "int", nullable: false),
                    AnswerText = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    IsCorrect = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Tbl_Answer", x => x.AnswerID);
                    table.ForeignKey(
                        name: "FK_Tbl_Answer_Tbl_Question_QuestionID",
                        column: x => x.QuestionID,
                        principalTable: "Tbl_Question",
                        principalColumn: "QuestionID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Tbl_Answer_QuestionID",
                table: "Tbl_Answer",
                column: "QuestionID");

            migrationBuilder.CreateIndex(
                name: "IX_Tbl_Exam_CreatorUserID",
                table: "Tbl_Exam",
                column: "CreatorUserID");

            migrationBuilder.CreateIndex(
                name: "IX_Tbl_Question_ExamID",
                table: "Tbl_Question",
                column: "ExamID");

            migrationBuilder.CreateIndex(
                name: "IX_Tbl_Result_ExamID",
                table: "Tbl_Result",
                column: "ExamID");

            migrationBuilder.CreateIndex(
                name: "IX_Tbl_Result_UserID",
                table: "Tbl_Result",
                column: "UserID");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Tbl_Answer");

            migrationBuilder.DropTable(
                name: "Tbl_Result");

            migrationBuilder.DropTable(
                name: "Tbl_Question");

            migrationBuilder.DropTable(
                name: "Tbl_Exam");

            migrationBuilder.DropTable(
                name: "Tbl_User");
        }
    }
}
