﻿using System.ComponentModel.DataAnnotations;

namespace WebApplication6.Models
{
    public class Answer
    {
        [Key]
        public int AnswerID { get; set; }

        public int QuestionID { get; set; }

        public virtual Question Question { get; set; } = null!;

        [Required]
        public string AnswerText { get; set; } = string.Empty;

        public bool IsCorrect { get; set; }
    }
}
