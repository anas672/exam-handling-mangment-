﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace WebApplication6.Models
{
    public class Exam
    {
        [Key]
        public int ExamID { get; set; }

        [Required]
        public string ExamName { get; set; } = string.Empty;

        public string Description { get; set; } = string.Empty;

        public DateTime DateCreated { get; set; } = DateTime.Now;

        public int CreatedBy { get; set; }

        public virtual User Creator { get; set; } = null!; // Reference to the creator

        public virtual ICollection<Question> Questions { get; set; } = new List<Question>();

        public virtual ICollection<Result> Results { get; set; } = new List<Result>();
    }
}
