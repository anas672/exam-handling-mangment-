﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace WebApplication6.Models
{
    public class Question
    {
        [Key]
        public int QuestionID { get; set; }

        public int ExamID { get; set; }

        public virtual Exam Exam { get; set; } = null!;

        [Required]
        public string QuestionText { get; set; } = string.Empty;

        [Required]
        public string QuestionType { get; set; } = string.Empty;

        public virtual ICollection<Answer> Answers { get; set; } = new List<Answer>();
    }
}
