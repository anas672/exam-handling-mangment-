﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WebApplication6.Models
{
    public class Result
    {
        [Key]
        public int ResultID { get; set; }

        public int UserID { get; set; }

        public virtual User User { get; set; } = null!;

        public int ExamID { get; set; }

        public virtual Exam Exam { get; set; } = null!;

        [Range(0, 100)]
        [Column(TypeName = "decimal(5, 2)")]
        public decimal Score { get; set; }

        public DateTime DateTaken { get; set; } = DateTime.Now;
    }
}
