﻿using Microsoft.AspNetCore.Identity;

namespace WebApplication6.Models
{
    public class Users: IdentityUser

    {
        public String FullName {  get; set; }
    }
}
