﻿using System.ComponentModel.DataAnnotations;

namespace WebApplication6.Models.ViewModel
{
    public class LoginViewModel
    {
        [Required(ErrorMessage = "Email is incorrect")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Password is incorrect")]
        [DataType(DataType.Password)]
        public string Password { get; set; }

        [Display(Name ="Remember me?")]
        public Boolean RememberMe { get; set; }
    }
}
