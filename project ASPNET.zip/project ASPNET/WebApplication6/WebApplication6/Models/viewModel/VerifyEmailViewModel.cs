﻿using System.ComponentModel.DataAnnotations;

namespace WebApplication6.Models.viewModel
{
    public class VerifyEmailViewModel
    {

        [Required(ErrorMessage = "Email is required.")]
        [EmailAddress]
        public string Email { get; set; }
    }
}
